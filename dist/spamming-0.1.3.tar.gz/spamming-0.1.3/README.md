# Spamming

A package for spamming people

# Usage

`pip install spamming`, obvisouly

`spamming.nonsense.main(nbr=15, slw=10)` for spamming 15 messages of random text, every 5 seconds

`spamming.spamclick.main(clicks=12)` for clicking 12 times automatically